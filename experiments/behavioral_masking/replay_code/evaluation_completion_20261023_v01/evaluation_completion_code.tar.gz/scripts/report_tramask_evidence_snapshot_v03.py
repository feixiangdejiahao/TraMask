"""Produce a reviewable interim report without claiming unfinished pilots ran."""
from collections import Counter
from pathlib import Path
import csv
import html
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tramask_pilot.corpus import read, receipt
from tramask_rerun.study import RUN, now, write_new


def esc(value):
    return html.escape(str(value))


def table(headers, rows):
    return '<table><thead><tr>' + ''.join('<th>' + esc(h) + '</th>' for h in headers) + '</tr></thead><tbody>' + ''.join(
        '<tr>' + ''.join('<td>' + esc(c) + '</td>' for c in row) + '</tr>' for row in rows) + '</tbody></table>'


def interval(metric):
    if metric['n'] == 0:
        return '不可估计（分母 0）'
    a, b = metric['ci95']
    return f"{metric['successes']}/{metric['n']}；{metric['rate']:.1%} [Wilson 95%: {a:.1%}, {b:.1%}]"


if __name__ == '__main__':
    out = RUN / 'evaluation_snapshot_v03'
    if out.exists():
        raise FileExistsError(out)
    checklist = read(RUN / 'evidence_aggregation_v01/pilot1_checklists.json')
    semantic = read(RUN / 'evidence_aggregation_v01/semantic_reviews.json')
    reviews = {r['pair_id']: r for r in semantic['groups']['candidates8']['pairs']}
    candidates = []
    for mapping in read(RUN / 'neutral_candidate_review_mapping_v01.json'):
        review = reviews[mapping['pair_id']]
        cell = Path(mapping['cell'])
        cid, method, rep = mapping['case_id'], cell.parent.name, int(cell.name[-2:])
        q = mapping['comparator_execution'] is not None
        notes = {
            ('HF001', 'M1'): '新增规则注册 import；原测试与增强测试均通过，未建立新增区分能力。',
            ('HF003', 'M1'): '保留的旧 input 数量断言先失败，新增 bold 断言未执行到；不能算新发现。',
            ('HF003', 'M2'): '新 image accept 测试在 P 通过、在事后独立构造 Q 上失败；旧 input 断言仍失败。精确格式 oracle / 冻结 target 范围须分别看独立审查。',
            ('HF005', 'M2'): '新增 AS 格式断言在 P 通过、在事后独立构造 Q 上失败；旧 aggregate 缩进断言仍失败，完整测试 oracle 未获认可。',
        }
        candidates.append({**mapping, 'method': method, 'physical_repeat': rep, 'rank': 1,
            'counterfactual_relevance': review['gate_checks']['E3']['status'],
            'strict_context_legality': review['gate_checks']['E7']['status'],
            'whole_augmented_oracle': review['gate_checks']['E9']['status'],
            'added_component_oracle': review['added_component']['status'],
            'P_original_and_augmented_commands': 6, 'Q_original_and_augmented_commands': 6 if q else 0,
            'added_component_P_Q_contrast_observed': q, 'R1_paired_executable': 'pass' if q else 'unresolved',
            'strict_R2_established': False, 'whole_oracle_qualified_improvement_established': False,
            'newly_exposed_real_P_defect_established': False, 'reason': notes[(cid, method)],
            'semantic_evidence': receipt(RUN / 'evidence_aggregation_v01/semantic_reviews.json'),
            'comparator_policy': 'Where present, root constructed evaluation Q after generated edits and P runs froze; withheld from generators; not a pre-existing gold witness or blind comparator author.'})
    supplement = read(RUN / 'hf001_evaluator_completion_v01/summary.json')
    by_cell = {r['cell']: r for r in supplement['pairs']}
    for row in candidates:
        if row['cell'] not in by_cell:
            continue
        update = by_cell[row['cell']]
        row['prior_semantic_evidence'] = row['semantic_evidence']
        row.update(counterfactual_relevance=update['checks']['E3']['status'],
            strict_context_legality=update['checks']['E7']['status'],
            whole_augmented_oracle=update['checks']['E9']['status'],
            comparator_execution=update['new_Q_results'], Q_original_and_augmented_commands=6,
            R1_paired_executable=update['R1_paired_executable'],
            added_component_P_Q_contrast_observed=False,
            original_test_P_Q_contrast_observed=update['original_test_distinguishes_qualified_Q'],
            additional_discrimination_over_original_test_observed=False,
            semantic_evidence=receipt(RUN / 'hf001_evaluator_completion_v01/summary.json'),
            reason='补齐冻结后独立 Q 评估：原始与增强测试在 P 各 3/3 PASS，在 Q 各 3/3 FAIL，均触发原有 b 行尾空格断言。原测已区分 Q，新增 import 未带来额外区分。')
    write_new(out / 'candidate_endpoints.json', {'created_at': now(), 'candidates': candidates,
        'distinct_issues': len({r['case_id'] for r in candidates}), 'physical_candidates': len(candidates),
        'confirmed_strict_context_witnesses': 0, 'whole_oracle_qualified_improvements': 0,
        'independently_established_new_P_defect_issues': 0,
        'limits': 'Only eight actually generated and structurally valid candidates; missing calls are not negative outcomes. Added-component evidence is secondary to the registered whole-validation endpoint.'})
    ledger = read(RUN / 'provider_budget.json')
    used = sum(c['charged_tokens'] for c in ledger['calls'].values())
    assert all(c['status'] == 'settled' for c in ledger['calls'].values())
    stage1 = Counter(); stage2 = Counter(); methods = {m: Counter() for m in ('M1', 'M2', 'M3', 'M4')}
    for path in (RUN / 'runs').glob('*/track_b/*/repeat_*/stage_01/result.json'):
        d = read(path); stage1[d['status']] += 1; methods[path.parents[2].name][d['status']] += 1
    for path in (RUN / 'runs').glob('*/track_b/*/repeat_*/stage_02/result.json'):
        d = read(path); status = 'budget_missing_zero_call' if d.get('provider_status') == 'budget_exceeded' else d['status']
        stage2[status] += 1; methods[path.parents[2].name]['stage2_' + status] += 1
    checkpoints = []
    from tramask_rerun.reserved import load_cases
    for case in load_cases():
        checkpoint = case['checkpoint']
        checkpoints.append({'case_id': case['id'], 'checkpoint': checkpoint,
            'scope': 'Recorded delivered tracked/index state and explicitly audited submodule state; replay filesystem inventories preserve generated /tmp/dependency artifacts, but a complete historical untracked-byte manifest is unavailable. Docker commit is not process-memory checkpointing.'})
    write_new(out / 'checkpoint_index.json', {'created_at': now(), 'checkpoints': checkpoints,
        'qualification': 'Use active checkpoint and authoritative validation receipts, not superseded summary flags.'})
    summary = {'created_at': now(), 'study_status': 'incomplete_under_authorized_provider_cap',
        'provider': {'cap': ledger['limit_tokens'], 'used': used, 'remaining': ledger['limit_tokens'] - used,
                     'physical_calls': len(ledger['calls']), 'prior_round_excluded': 7255383},
        'pilot1': checklist['metrics'], 'review_agreement': semantic['all60_initial_agreement'],
        'pilot2': {'eligible_technical_candidate_ids': ['HF012'], 'calls_completed': 0,
                   'strict_taxonomy_conflict': 'HF012 observation_gap', 'recall_and_MRR': None},
        'pilot3': {'candidate_level_n': 1, 'independent_gold_witness_n': 0, 'generation_or_repair_completed': False,
                   'R2_rate': None, 'R3_rate': None, 'one_factor_success_rate': None, 'false_rejection_rate': None},
        'pilot4': {'track_a_completed': False, 'track_b_registered_cells': 160, 'stage1': dict(stage1),
                   'stage2': dict(stage2), 'by_method': {m: dict(v) for m, v in methods.items()},
                   'method_comparison_complete': False, 'causal_effect_claim_supported': False},
        'thresholds': {'replay_feasibility': 'met_for_selected_E1_tests_59_of_60',
            'four_confirmed_witnesses_three_issues': 'not_met_0_confirmed',
            'trajectory_gain_15pp_or_execution_reduction25pct': 'not_evaluated',
            'one_factor_half_verified_repairable': 'undefined_no_gold_and_candidate_search_not_run'},
        'sources': [receipt(RUN / 'evidence_aggregation_v01/pilot1_checklists.json'),
                    receipt(RUN / 'evidence_aggregation_v01/semantic_reviews.json'),
                    receipt(RUN / 'provider_budget.json'), receipt(out / 'candidate_endpoints.json')]}
    for name in ['cost_and_flow_audit_v02.json', 'requirements_completion_audit_v02.json',
                 'continuation_budget_preflight_v01.json', 'continuation_budget_preflight_v02.json',
                 'reusable_code_archive_v01.json']:
        if (RUN / name).exists():
            summary['sources'].append(receipt(RUN / name))
    summary['pilot4']['additional_evaluator_completion'] = receipt(RUN / 'hf001_evaluator_completion_v01/summary.json')
    summary['pilot4']['trajectory_baseline_is_fully_history_free'] = False
    summary['pilot4']['chronology_design_limitation_repaired'] = False
    for name in ['hf001_evaluator_completion_v01/summary.json', 'serialized_input_provenance_audit_v01.json',
                 'serialized_input_provenance_audit_v01/chronology_visibility_addendum.json',
                 'serialized_input_provenance_audit_v01/chronology_protocol_deviation_notice_v01.json', 'continuation_preparation_readiness_v01.json']:
        summary['sources'].append(receipt(RUN / name))
    write_new(out / 'summary.json', summary)
    sections = [f'<h1>TraMask 新一轮实验：预算边界下的证据报告</h1><p>生成时间 {esc(summary["created_at"])}。<strong>这是可复核的中期结果；四组 pilot 尚未全部完成。</strong></p>',
        '<p>本轮单独使用 1,000 万 DeepSeek tokens，上一轮 7,255,383 不计入。当前 280 次真实调用已结算 9,968,405 tokens，余 31,595；没有超出上限。DeepSeek 用于方案生成，独立语义审查由两个 Codex 线程完成。</p>',
        '<h2>Replay 与样本</h2><p>60 个不同 issue：旧 40 个已探索案例 + 20 个预留案例，共 45 failed、15 successful。没有按结果替换案例。60 个 active 提交终态 checkpoint 已保留；原测试稳定执行 E1 为 59/60（98.3%，Wilson 95% 91.1%–99.7%）。HF008 在重新构建时遇到依赖下载/DNS 障碍，不能将旧二进制当作新 Q 的执行。</p>',
        '<p>状态复现与 stdout 逐字一致是两个指标。这里使用提交 tracked tree、index/worktree 与显式 submodule 校验；保留 /tmp 和依赖文件清单。原始数据没有完整历史 untracked 文件逐字节清单，因此不宣称对此有完全历史同一性证明；Docker 文件系统快照也不等于进程内存快照。删除的历史测试另作显式版本分层，未用旧测试或源码覆盖提交状态来“修复”replay。</p>',
        '<h2>Pilot 1：现象证据</h2><p>可分析比较分母为 E1 与独立 E3 均成立的 47 个固定 target–test–Q pair。保留未解决的 E2/E4/E5；不只选结论明确的案例。每 trial 只分析所选 pair，不能外推到全部验证测试或 211 条 failed trials。</p>']
    sections.append(table(['分层', '已登记', 'E1 稳定恢复', '局部 E1–E6', 'Confirmed（保守已观察下界）'], [
        [name, m['registered'], interval(m['E1_replay']), interval(m['technical_candidate_rate']), interval(m['confirmed_rate_conservative_lower_bound'])]
        for name, m in checklist['metrics'].items()]))
    sections.append('<p><strong>HF012：</strong>4 个原输入下，P 完整返回列表有 1 个 Key，Q 有 2 个 Key；原测试只检查 evs[0]，第一个 Key 的字段相同，37 个原 check 调用均通过。局部 E1–E6 成立，但额外 Key 已在对外列表中，属于 Observation Gap 证据；没有观察到上下文将其消除。它不能计作严格 masking，也不能从候选级后续分母消失。当前 E7/E8 尚未建立。</p>')
    sections.append(table(['当前分类', '数量'], sorted(checklist['metrics']['all60']['classifications'].items())))
    sections.append('<p>38 个可运行且相关的 Q 已被原测试区分；7 个 Q 被独立审查判无效；7 个证据不全；4 个目标未激活；3 个 weak oracle；HF012 为局部候选与非 masking 分类证据冲突。没有已确认 witness，不意味着已证明任何合法 witness 都不存在。</p>')
    sections.append('<h2>两个 Codex 线程如何判断</h2><p>使用 collaboration.spawn_agent 启动 reference_semantic_reviewer_a_v01 和 reference_semantic_reviewer_b_v01，fork_turns="none"，不指定 model override。两条线程分别读取同一中性 packet：issue、固定 P/Q 的源码、原测试、原始执行日志；不读取方法身份、模型理由、旧标签、其它审查者答案或人工 masker。先各自完成 40 项，再各自审查 20 项和单独盲化的 8 个候选。首次任务与输出路径保存在 thread_launches.json。它们是 AI 审查者，不是两名人类研究者。</p><p>线程只给 E3（Q 相关性）、E7（context 合法性）、E9（oracle）结构化判断和证据。标签由 E1–E9 组合派生。6 个参考案例的初始语义分歧、1 个候选新增组件分歧均交第三个独立 Codex 线程裁决，保留 A/B 原回答。未取得 token 数据的 Codex 审查成本为 null，时间记录是线程墙钟时间，不能冒充人工工时。</p>')
    sections.append(table(['初始语义判断', '一致率', 'Cohen κ', '说明'], [[topic, f"{v['agreements']}/{v['n_paired']} ({v['raw_agreement']:.1%})", v['cohen_kappa'],
        '全部 unresolved；不构成合法 context 证据' if topic == 'context_legality' else '第三方裁决不改变初始一致率'] for topic,v in semantic['all60_initial_agreement'].items()]))
    sections.append('<p>HF001 补充评价另启动 hf001_evaluator_reviewer_a_v01 与 hf001_evaluator_reviewer_b_v01 两个 fork_turns="none" 线程，分别读取两份同内容范围的中性 packet、24 次 P/Q 原始日志及同一 checkpoint 的源码补充。两者的 E3/E7/E9 均为 pass；这是一个 issue 的两个已生成候选实例，各项初始一致率 2/2，因标签恒定 κ 不可定义。保留补充前缺少模块源码时的草稿，不覆盖原始 8 候选审查。源码补充是只读导出，不修改测试或 P/Q。</p>')
    sections.append('<h2>Pilot 2、Pilot 3 与 Track A</h2><p>HF012 作为唯一局部 E1–E6 候选保留；独立 gold witness 数为 0。C1–C4 与 Track A 的候选生成尚未运行，Recall/MRR、R2/R3 比率、最小化和 one-factor 成功率均不可估计，不能写作 0% 或已完成。12 个物理请求已本地准备；M3/C2、M4/C3 共享请求，不增加虚假重复。不会将没有 gold 偷换为候选分母为空。</p>')
    sections.append('<h2>Pilot 4 Track B：实际执行与缺失</h2><p>20 个预留 trial × 4 方法 × 2 次物理重复 = 160 个登记单元。Stage 1：72 个直接方法 target、58 个显式弃权、8 个 Two-Flip 方案、6 个无效响应、16 个输入超限。输入超限来自 HF004/HF011 的完整版本 inventory；没有裁掉测试来伪装完整输入。Stage 2：36 次完成，36 个直接方法请求因预算未调用。原 wrapper 对这些零调用记录写了 invalid_response，报告按 provider 的 budget_exceeded 单列为缺失。</p>')
    sections.append(table(['方法', 'Stage1 target/Two-Flip', '弃权', '无效响应', '输入不可用', 'Stage2 完成', 'Stage2 预算缺失'], [
        [m, c['planning_qualified_for_next_generation'] + c['planning_requires_Q_execution_qualification'], c['explicit_planning_abstention'], c['invalid_response'], c['input_unavailable'], c['stage2_candidates_pending_execution_and_oracle_qualification'], c['stage2_budget_missing_zero_call']] for m,c in methods.items()]))
    sections.append('<p>8 个 Two-Flip 方案各运行 3 次 × P/Q 原版及插桩版，共 96 次。原始方案没有获得完整可对齐的双通道测量；缺失事件不能当相等，也没有替模型修改探针。Jest/pytest 包裹的原始事件另行机械解码，仍不补造缺失通道或调用身份。</p><p>36 次真实 Stage 2 输出包含 180 个候选槽：8 个可应用、4 个无效、168 个 no_proposal。8 个候选完成 48 次 P 原版/增强运行；6 个候选另做 36 次事后构造 Q 的评估运行，其中 HF001 两例的 12 次为本次补完。3 个 issue 的重复输出不算 8 个独立案例。</p>')
    sections.append(table(['案例 / 方法 / 重复', 'E3', '严格 E7', '完整 oracle', '新增部分 oracle', '观察'], [
        [f"{r['case_id']} {r['method']} r{r['physical_repeat']}", r['counterfactual_relevance'], r['strict_context_legality'], r['whole_augmented_oracle'], r['added_component_oracle'], r['reason']] for r in candidates]))
    sections.append('<p>当前没有建立严格 context witness、完整 oracle 合格的验证改进或新增真实 P 缺陷。部分新增断言确有局部区分能力，但旧断言原已失败、oracle 过约束或目标不对应的问题分别保留。不能把原有失败归功于新增测试。由于方法单元尚有预算缺失，完整主效应、交互效应及因果比较暂不可报告。</p>')
    if (RUN / 'cost_and_flow_audit_v02.json').exists():
        cost = read(RUN / 'cost_and_flow_audit_v02.json')
        sections.append('<h2>实际成本</h2><p>provider 账本与唯一调用收据逐项核对：输入 9,777,041，输出 191,364，共 9,968,405 tokens。请求 model 为 deepseek-v4-flash；全部响应报告别名 deepseek-flash，原始响应保留，不能额外推断服务商内部 checkpoint。运行层计 835 条实际测试/验证命令；33 条构建、225 次文件导出、2,997 条新预留案例历史 replay 命令另列。旧 40 个提交终态 replay 的 6,591 条历史命令属于上一轮状态构建，不再次记入本轮新执行。</p>')
        sections.append(table(['阶段', '方法', '真实调用', '输入 tokens', '输出 tokens', '总 tokens'], [
            [r['phase'] + (f" stage {r['stage']}" if r['stage'] else ''), r['method'] or '—', r['external_model_calls'], r['input_tokens'], r['output_tokens'], r['total_tokens']]
            for r in cost['provider_cost_by_phase']]))
        sections.append('<p>Stage 1 每个方法均有 36 个真实调用 / 18 个 issue，可做实际定位阶段成本的配对分析。Stage 2 M1/M2 只有 17 个共同可用重复单元 / 9 个 issue，相关成本比较仅作次要分析；40 个登记重复单元的完整估计与 CI 保持 null。所有重复按 issue 聚类。当前没有有效完整改进，因此 cost-per-success 不可估计。False rejection rate 也不可估计，原因是尚未建立足够的、独立确认当前被检行为正确的 P 评估分母；不能从成功数为零推出这一点。</p>')
    provenance = read(RUN / 'serialized_input_provenance_audit_v01.json')
    assert provenance['physical_call_count'] == provenance['calls_passing_all_mechanical_checks'] == 280
    sections.append('<h2>实际模型输入来源与消融限制</h2><p>已对全部 280 个实际请求逐项核对 serialized payload、prepared_request、manifest 请求哈希和已结算账本，并用归档构造器与原始公共材料完整复现输入。36 个 Stage 1 四臂块的非 actions 材料逐字段相同；18 个 case 的两个重复也保持共同材料一致。测试文件、源码片段、patch 和 action/output 均绑定原始存档。HF002 的 10 次整文件历史查找失败明确保留，并分别核对终态生产前缀与历史测试后缀的组合；这不是修改旧实验数据。</p>')
    sections.append('<p><strong>未修复的设计偏差：</strong>M1/M3 未收到 actions 字段，但四臂共同使用包含历史版本的测试清单。18 个实际调用 case、144 次 Stage 1 的清单均保留原始 invocation 先后顺序；556 个唯一测试条目、4,584 个实际输入测试对象没有显式 step/action-id/timestamp 字段，但数组顺序仍携带隐式时序。因此不能将基线称为完全不含历史或时序信息，也不能据此声称严格隔离了 trajectory/chronology 因果贡献。现有输入可解释额外 raw tool events 的差异，但这种较窄解释不代表原目标已经满足；完成现有 49 个待发请求也不能消除先前暴露。</p>')
    sections.append('<p>来源机械一致不证明此前研究者从未接触数据，也不证明 blind gold 的建立时点、文件系统 ACL 隔离、所有语义泄漏均不存在或排序过程独立。主输入审计中的“未解决机械异常为 0”不包含上述设计偏差；两者单列。C4 尚无实际调用，预构造检查不算消融实验结果。</p>')
    sections.append('<h2>协议边界及下一步</h2><p>初始协议在预留轨迹读取前冻结，但后续有公开、追加式修订，包括材料编码、历史测试版本绑定、Track B endpoint 和运行接口。必须将本轮称为带修订的 pilot，不能声称全程一次冻结。全局预算上限有效，但没有为完整 balanced block 预留足够余额，导致部分 Stage 2 缺失；这些缺失不是方法失败。</p><p>科学门槛：稳定 replay 达到约 80% 的参考门槛；至少 4 个 confirmed witness / 3 个 issue 的门槛未达到；trajectory 增益和一 factor 修复门槛尚未评估。仍需补登记队列中未调用的请求与 HF012 候选级固定 pair 实验，并处理上述消融输入设计限制。旧结果和拒绝记录继续保留；不能通过事后改写输入或缩小目标宣称完整实验已完成。</p>')
    sections.append('<p>续跑预检已准备 49 个请求：36 个原零调用 Stage 2、HS005 的 1 个原零调用 Q 材料补全、HF012 的 12 个固定 pair 请求。全部保守预留为 2,604,952 tokens；扣除余额需 2,573,357，建议追加上限 260 万、总上限 1,260 万。历史比例约估 63.2 万实际新 tokens，不是上界。这项 260 万追加预估仅覆盖现有 49 个请求，不包含为修复历史测试排序偏差而另行重跑的对照实验；它不是完整研究完成所需预算的保证。未获新增预算授权前不发送。</p><p>首次 P2/Track A 生成前还修正了一个纯材料构造错误：小的必需 Q 邻域曾被可选的大 patch 邻域合并，错误触发源码配额。新版本先保留完整必需邻域，再填入可选上下文；10,000 字节源码配额和原总输入上限均不变。v01 构造失败保留，v02 全部 12 个请求可构造，C3/C4 的事件集合相同。该构造修正冻结时的全套本地测试为 334 项通过（见 amendment 015 的 validation receipt）。</p>')
    links = [('逐案 E1–E9 JSON', '../evidence_aggregation_v01/pilot1_checklists.json'), ('60 案例 CSV', '../evidence_aggregation_v01/pilot1_cases.csv'),
        ('全部独立语义审查汇总', '../evidence_aggregation_v01/semantic_reviews.json'), ('线程启动记录', '../neutral_reference_review_v01/thread_launches.json'),
        ('8 候选 endpoint', 'candidate_endpoints.json'), ('成本与执行 flow', '../cost_and_flow_audit_v02.json'),
        ('93 项要求完成审计', '../requirements_completion_audit_v02.json'), ('续跑预算预检', '../continuation_budget_preflight_v02.json'),
        ('可复用代码归档', '../reusable_code_archive_v01.json'), ('Checkpoint 索引', 'checkpoint_index.json'), ('冻结协议', '../protocol.json')]
    links.extend([('HF001 补充成对评价及审查', '../hf001_evaluator_completion_v01/summary.json'),
        ('补充审查线程启动记录', '../neutral_hf001_evaluator_review_v01/thread_launches.json'),
        ('280 实际模型输入来源审计', '../serialized_input_provenance_audit_v01.json'),
        ('隐式时序偏差', '../serialized_input_provenance_audit_v01/chronology_protocol_deviation_notice_v01.json'),
        ('续跑代码与材料保留记录', '../continuation_preparation_readiness_v01.json')])
    sections.append('<h2>原始证据入口</h2><ul>' + ''.join('<li><a href="' + esc(url) + '">' + esc(label) + '</a></li>' for label,url in links) + '</ul>')
    sections.append('<h2>60 个固定参考 pair</h2>')
    sections.append(table(['ID','cohort','partition', *[f'E{i}' for i in range(1,10)],'classification'], [
        [r['case_id'],r['cohort'],r['partition'], *[r['evidence']['checks'][f'E{i}']['status'] for i in range(1,10)], r['evidence']['classification']] for r in checklist['cases']]))
    document = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TraMask evidence snapshot</title><style>body{font:16px/1.65 system-ui,sans-serif;max-width:1400px;margin:2rem auto;padding:0 1rem;color:#182333}h1,h2{line-height:1.3}h2{margin-top:2.5rem}table{border-collapse:collapse;display:block;overflow-x:auto;margin:1rem 0;font-size:14px}th,td{border:1px solid #cbd5e1;padding:.5rem .7rem;vertical-align:top}th{background:#eef3f8;text-align:left}tr:nth-child(even){background:#f8fafc}a{color:#164eaf}p{max-width:1050px}</style><body>' + ''.join(sections) + '</body></html>'
    (out / 'report.html').write_text(document)
    write_new(out / 'manifest.json', {'created_at': now(), 'artifacts': [receipt(p) for p in sorted(out.iterdir()) if p.is_file()], 'implementation': receipt(Path(__file__))})
    print(json.dumps({'report': str(out / 'report.html'), 'status': summary['study_status'], 'used_tokens': used}))
