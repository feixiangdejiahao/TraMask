#!/usr/bin/env python3
"""Pure-local audit. Reads frozen artifacts; writes only this new audit version."""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import itertools
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]


def read(path):
    return json.loads(Path(path).read_text())


def receipt(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def dump(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def csv_write(name, rows):
    rows = list(rows)
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with (OUT / name).open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
                             for k, v in row.items()})


cases = {row["id"]: row for row in read(ROOT / "cases.json")["cases"]}


def case_fields(cid):
    c = cases[cid]
    return {"case_id": cid, "issue_id": c["task"], "trial_id": c["trial"],
            "cohort": c["cohort"], "partition": c["partition"], "language": c["language"]}


def sum_observed(rows, field):
    values = [r[field] for r in rows if r.get(field) is not None]
    return sum(values) if values else None


def aggregate(rows, keys):
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row.get(k) for k in keys)].append(row)
    result = []
    for group, members in sorted(groups.items(), key=lambda item: str(item[0])):
        row = dict(zip(keys, group))
        row.update(records=len(members), n_issues=len({m["issue_id"] for m in members}),
                   external_model_calls=sum(m["external_model_calls"] for m in members),
                   provider_status_counts=dict(Counter(m["provider_status"] for m in members)),
                   input_tokens=sum_observed(members, "input_tokens"),
                   output_tokens=sum_observed(members, "output_tokens"),
                   total_tokens=sum_observed(members, "total_tokens"),
                   charged_tokens=sum_observed(members, "charged_tokens"),
                   provider_seconds=sum_observed(members, "provider_seconds"),
                   n_dispatched_missing_usage=sum(m["external_model_calls"] > 0 and m["total_tokens"] is None for m in members),
                   n_dispatched_missing_seconds=sum(m["external_model_calls"] > 0 and m["provider_seconds"] is None for m in members),
                   n_zero_call_budget_exceeded=sum(m["provider_status"] == "budget_exceeded" for m in members))
        result.append(row)
    return result


ledger = read(ROOT / "provider_budget.json")
providers = []
provider_by_path = {}
for path in sorted(ROOT.glob("runs/**/provider/manifest.json")):
    data = read(path)
    parts = path.relative_to(ROOT).parts
    usage = data.get("usage") or {}
    physical = data.get("external_model_calls")
    track = parts[2] == "track_b"
    row = {**case_fields(parts[1]), "phase": "track_b" if track else parts[2],
           "method": parts[3] if track else None,
           "physical_repeat": int(parts[4].split("_")[1]) if track else 1,
           "stage": int(parts[5].split("_")[1]) if track else None,
           "provider_status": data.get("status"), "external_model_calls": physical,
           "budget_key": data.get("budget_key"), "request_sha256": data.get("request_sha256"),
           "request_id": data.get("request_id"), "requested_model": data.get("model"),
           "response_model": data.get("response_model"),
           "input_tokens": usage.get("prompt_tokens"), "output_tokens": usage.get("completion_tokens"),
           "total_tokens": usage.get("total_tokens"),
           "charged_tokens": (data.get("budget") or {}).get("charged_tokens", 0 if physical == 0 else None),
           "provider_seconds": data.get("seconds"), "provider_manifest": str(path),
           "provider_manifest_sha256": receipt(path)["sha256"],
           "wrapper_status": read(path.parent.parent / "result.json").get("status") if (path.parent.parent / "result.json").exists() else None,
           "usage_state": "observed_provider_usage" if usage else "zero_call_no_response_usage" if physical == 0 else "missing_usage"}
    providers.append(row)
    provider_by_path[str(path)] = row

actual = [r for r in providers if r["external_model_calls"] > 0]
key_counts = Counter(r["budget_key"] for r in actual)
keys = set(key_counts)
ledger_keys = set(ledger["calls"])
mismatches = []
for row in actual:
    entry = ledger["calls"].get(row["budget_key"])
    if entry is None or entry.get("charged_tokens") != row["total_tokens"] or entry.get("request_sha256") != row["request_sha256"]:
        mismatches.append(row["provider_manifest"])
charged = sum(entry["charged_tokens"] for entry in ledger["calls"].values())
assert len(actual) == 280 and len(keys) == 280 and keys == ledger_keys
assert not mismatches and charged == 9968405
assert all(entry["status"] == "settled" for entry in ledger["calls"].values())
assert sum(r["total_tokens"] for r in actual) == charged


def runtime_category(parts):
    phase = parts[2]
    if phase == "track_b":
        if "evaluator_comparator_v01" in parts:
            return "track_b_postfreeze_evaluator_Q"
        if "candidate_execution" in parts:
            return "track_b_direct_candidate_P"
        if "target_execution" in parts:
            return "track_b_target_qualification"
        return "track_b_other"
    if phase in {"baseline", "baseline_capsule", "baseline_uncached", "runner_qualification_v01"}:
        return "baseline_and_runner_qualification"
    if phase.startswith("original_pair_controls") or phase == "full_capture_controls_v01":
        return "original_PQ_controls"
    if phase.startswith("measurement_execution"):
        return "reference_probe_and_paired_original_controls"
    return phase


runtimes, builds, exports, replays = [], [], [], []
for path in sorted(ROOT.glob("runs/**/result.json")):
    data = read(path)
    parts = path.relative_to(ROOT).parts
    if not isinstance(data, dict):
        continue
    ex = data.get("execution")
    if isinstance(ex, dict) and ex.get("command"):
        track = parts[2] == "track_b"
        repeats = [int(p.split("_")[1]) for p in parts if p.startswith("repeat_")]
        row = {**case_fields(parts[1]), "category": runtime_category(parts), "phase": parts[2],
               "method": parts[3] if track else None, "physical_repeat": repeats[0] if track else None,
               "execution_repeat": repeats[-1] if repeats else None,
               "arm": parts[-2] if parts[-2].startswith(("p_", "q_")) else "P_baseline",
               "status": data.get("status"), "returncode": ex.get("returncode"),
               "timed_out": ex.get("timed_out"), "elapsed_seconds": ex.get("elapsed_seconds"),
               "command_sha256": ex.get("command_sha256"), "command": ex["command"],
               "container": ex.get("container"), "raw_stdout": ex.get("raw_stdout"),
               "result_path": str(path), "result_sha256": receipt(path)["sha256"]}
        runtimes.append(row)
    for idx, build in enumerate(data.get("builds", [])):
        if build.get("command"):
            builds.append({**case_fields(parts[1]), "category": "build", "phase": parts[2],
                           "build_index": idx, "command": build["command"],
                           "command_sha256": build.get("command_sha256"),
                           "elapsed_seconds": build.get("elapsed_seconds"),
                           "returncode": build.get("returncode"), "result_path": str(path)})
    if parts[2].startswith("submission_replay_v") and "calls" in parts and data.get("command_sha256"):
        replays.append({**case_fields(parts[1]), "category": "historical_action_replay",
                        "phase": parts[2], "action_id": data.get("id"), "command_sha256": data["command_sha256"],
                        "elapsed_seconds": data.get("elapsed_seconds"), "returncode": data.get("returncode"),
                        "result_path": str(path)})

for path in sorted(ROOT.glob("runs/**/manifest.json")):
    if path.parent.name not in {"export", "observations"}:
        continue
    data = read(path)
    if set(data) != {"files", "status"}:
        continue
    parts = path.relative_to(ROOT).parts
    exports.append({**case_fields(parts[1]), "category": "file_export_operation",
                    "phase": parts[2], "kind": path.parent.name, "status": data["status"],
                    "file_entries": len(data["files"]),
                    "file_status_counts": dict(Counter(f.get("status") for f in data["files"])),
                    "elapsed_seconds": None, "manifest_path": str(path)})

assert len(runtimes) == 835
runtime_counts = Counter(r["category"] for r in runtimes)
assert runtime_counts["track_b_target_qualification"] == 96
assert runtime_counts["track_b_direct_candidate_P"] == 48
assert runtime_counts["track_b_postfreeze_evaluator_Q"] == 36
assert len(exports) == 225
assert len({r["raw_stdout"] for r in runtimes}) == len(runtimes)

previous_audit = read(ROOT / "cost_and_flow_audit_v01.json")
with (ROOT / "cost_and_flow_audit_v01/runtime_commands.csv").open(newline="") as fh:
    previous_runtime_paths = {r["result_path"] for r in csv.DictReader(fh)}
with (ROOT / "cost_and_flow_audit_v01/export_operations.csv").open(newline="") as fh:
    previous_export_paths = {r["manifest_path"] for r in csv.DictReader(fh)}
new_runtime_rows = [r for r in runtimes if r["result_path"] not in previous_runtime_paths]
new_export_rows = [r for r in exports if r["manifest_path"] not in previous_export_paths]
assert previous_runtime_paths <= {r["result_path"] for r in runtimes}
assert previous_export_paths <= {r["manifest_path"] for r in exports}
assert len(new_runtime_rows) == 12 and all(
    r["case_id"] == "HF001" and r["category"] == "track_b_postfreeze_evaluator_Q"
    for r in new_runtime_rows)
assert len(new_export_rows) == 1 and new_export_rows[0]["file_entries"] == 2

target_audit = read(ROOT / "track_b_target_execution_audit_v01.json")
target_by_cell = {(r["case_id"], r["method"], r["physical_repeat"]): r for r in target_audit["cells"]}
semantic = read(ROOT / "evidence_aggregation_v01/semantic_reviews.json")
candidate_mapping = {r["cell"]: r for r in read(ROOT / "neutral_candidate_review_mapping_v01.json")}
candidate_reviews = {r["pair_id"]: r for r in semantic["groups"]["candidates8"]["pairs"]}
hf001_supplement_path = ROOT / "hf001_evaluator_completion_v01/summary.json"
hf001_supplement = read(hf001_supplement_path)
hf001_reviews_by_cell = {r["cell"]: r for r in hf001_supplement["pairs"]}
assert len(hf001_reviews_by_cell) == 2
assert abs(sum_observed(new_runtime_rows, "elapsed_seconds")
           - hf001_supplement["cost"]["new_Q_subject_seconds"]) < 0.000001
statuses = {"planning_qualified_for_next_generation": "planned_target",
            "explicit_planning_abstention": "abstain", "input_unavailable": "input_unavailable",
            "planning_requires_Q_execution_qualification": "twoflip_planning", "invalid_response": "invalid"}
cells = []
reserved = sorted(c for c in cases if cases[c]["partition"] == "reserved")
assert len(reserved) == 20
for cid, method, repeat in itertools.product(reserved, ["M1", "M2", "M3", "M4"], [1, 2]):
    cell_path = ROOT / "runs" / cid / "track_b" / method / f"repeat_{repeat:02d}"
    first = read(cell_path / "stage_01/result.json")
    second_path = cell_path / "stage_02/result.json"
    second = read(second_path) if second_path.exists() else None
    row = {**case_fields(cid), "cell_id": f"{cid}/{method}/repeat_{repeat:02d}", "method": method,
           "physical_repeat": repeat, "registered": True, "stage1_status": statuses[first["status"]],
           "stage1_wrapper_status": first["status"], "stage1_reason": first.get("reason"),
           "stage1_result": str(cell_path / "stage_01/result.json"),
           "stage2_wrapper_status": second.get("status") if second else None,
           "stage2_result": str(second_path) if second else None}
    provider_records = []
    for stage in [1, 2]:
        p = provider_by_path.get(str(cell_path / f"stage_{stage:02d}" / "provider/manifest.json"))
        result = first if stage == 1 else second
        row[f"stage{stage}_provider_status"] = p["provider_status"] if p else None
        row[f"stage{stage}_calls"] = p["external_model_calls"] if p else (result or {}).get("physical_model_calls", 0)
        for metric in ["input_tokens", "output_tokens", "total_tokens", "provider_seconds"]:
            row[f"stage{stage}_{metric}"] = p[metric] if p else None
        row[f"stage{stage}_provider_manifest"] = p["provider_manifest"] if p else None
        if p:
            provider_records.append(p)
    if second:
        row["stage2_status"] = "budget_missing_zero_call" if row["stage2_provider_status"] == "budget_exceeded" else "complete" if row["stage2_provider_status"] == "complete" else "other"
    else:
        row["stage2_status"] = "not_reached_" + row["stage1_status"]
    target = target_by_cell.get((cid, method, repeat))
    if target:
        row["target_qualified_for_stage2"] = target["qualified_for_stage2"]
        row["target_qualification_reason"] = target["reason"]
        row["stage2_status"] = "not_reached_target_execution_unqualified"
    cell_runs = [r for r in runtimes if r["case_id"] == cid and r["method"] == method and r["physical_repeat"] == repeat]
    for cat, field in [("track_b_target_qualification", "target_subject_commands"),
                       ("track_b_direct_candidate_P", "candidate_P_subject_commands"),
                       ("track_b_postfreeze_evaluator_Q", "postfreeze_Q_subject_commands")]:
        row[field] = sum(r["category"] == cat for r in cell_runs)
    row["actual_subject_commands"] = len(cell_runs)
    row["observed_subject_seconds"] = sum_observed(cell_runs, "elapsed_seconds")
    row["actual_model_calls"] = sum(p["external_model_calls"] for p in provider_records)
    row["actual_charged_tokens"] = sum(p["charged_tokens"] for p in provider_records)
    row["observed_provider_seconds"] = sum_observed(provider_records, "provider_seconds")
    row["complete_generated_stage2_cost_observed"] = row["stage2_status"] == "complete"
    row["budget_missing_is_method_failure"] = False
    row["candidate_slots_registered_at_stage2"] = second.get("registered_candidate_slots", 0) if second else 0
    row["structurally_proposed_slots"] = second.get("structurally_proposed") if second else None
    row["no_proposal_slots"] = second.get("no_proposal_slots") if second else None
    row["invalid_slots"] = second.get("invalid_slots") if second else None
    mapping = candidate_mapping.get(str(cell_path))
    if mapping:
        review = candidate_reviews[mapping["pair_id"]]
        row["review_pair_id"] = mapping["pair_id"]
        for key, value in review["judgments"].items():
            row["semantic_" + key] = value["status"]
        row["semantic_source"] = str(ROOT / "evidence_aggregation_v01/semantic_reviews.json")
        row["semantic_policy"] = "Copied authoritative A/B/C aggregation without overriding oracle judgments."
    supplement = hf001_reviews_by_cell.get(str(cell_path))
    if supplement:
        row["original_review_pair_id"] = row["review_pair_id"]
        row["original_semantic_source"] = row["semantic_source"]
        row["review_pair_id"] = supplement["pair_id"]
        for check, topic in [("E3", "counterfactual_relevance"),
                             ("E7", "context_legality"), ("E9", "oracle_validity")]:
            row["semantic_" + topic] = supplement["checks"][check]["status"]
        row["semantic_source"] = str(hf001_supplement_path)
        row["semantic_source_sha256"] = receipt(hf001_supplement_path)["sha256"]
        row["semantic_policy"] = "HF001 paired evaluation completed; copy independent A/B supplement, retain original review lineage. Pilot1 fixed pair unchanged."
        for key in ["R1_paired_executable", "original_test_distinguishes_qualified_Q",
                    "additional_discrimination_over_original_test_observed", "strict_R2_established",
                    "whole_oracle_qualified_improvement_established", "newly_exposed_real_P_defect_established"]:
            row[key] = supplement[key]
        row["candidate_evaluation_classification"] = supplement["classification"]
    cells.append(row)

assert len(cells) == 160
assert Counter(r["stage1_status"] for r in cells) == {"planned_target": 72, "abstain": 58, "input_unavailable": 16, "twoflip_planning": 8, "invalid": 6}
assert sum(r["stage2_status"] == "budget_missing_zero_call" for r in cells) == 36
assert sum(r["stage2_status"] == "complete" for r in cells) == 36
assert sum(r.get("semantic_source") == str(hf001_supplement_path) for r in cells) == 2

metric_path = REPO / "src/tramask_rerun/metrics.py"
spec = importlib.util.spec_from_file_location("tramask_audit_metrics", metric_path)
metrics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metrics)
paired = []
paired_flat = []
registrations = [{"id": f"{cid}/repeat_{repeat:02d}", "issue_id": cases[cid]["task"]}
                 for cid, repeat in itertools.product(reserved, [1, 2])]
for method_a, method_b in itertools.combinations(["M1", "M2", "M3", "M4"], 2):
    for stage in [1, 2]:
        if stage == 2 and (method_a not in {"M1", "M2"} or method_b not in {"M1", "M2"}):
            continue
        for metric, unit in [("input_tokens", "tokens"), ("output_tokens", "tokens"), ("total_tokens", "tokens"), ("provider_seconds", "seconds")]:
            def obs(method):
                return [{"id": f"{r['case_id']}/repeat_{r['physical_repeat']:02d}", "cost": r[f"stage{stage}_{metric}"]}
                        for r in cells if r["method"] == method]
            left, right = obs(method_a), obs(method_b)
            all_comparison = metrics.paired_cost_comparison(registrations, left, right, unit=unit)
            common_ids = {x["id"] for x, y in zip(left, right) if x["cost"] is not None and y["cost"] is not None}
            # The same explicit pair IDs, never pairs selected by observed success.
            if stage == 1:
                common = [r for r in registrations if r["id"] in common_ids]
                conditional = metrics.paired_cost_comparison(common, [r for r in left if r["id"] in common_ids],
                                                            [r for r in right if r["id"] in common_ids], unit=unit)
            else:
                conditional = None
            entry = {"method_a": method_a, "method_b": method_b, "stage": stage, "metric": metric,
                     "all_40_registered_pairs": all_comparison,
                     "stage1_common_dispatched_comparison": conditional,
                     "interpretation": "Measured stage1 cost conditional on both arms dispatched; 36 pairs across 18 issues. All 40 registrations retained separately."
                         if stage == 1 else "Stage2 budget truncation: available-pairs result is secondary only; no complete method-cost estimate.",
                     "pair_unit": "same issue and physical-repeat index", "independent_sampling_unit": "issue",
                     "physical_repeats_are_independent_issues": False}
            paired.append(entry)
            estimate = (conditional or all_comparison)["available_pairs_difference_a_minus_b"]
            paired_flat.append({"method_a": method_a, "method_b": method_b, "stage": stage, "metric": metric,
                                "n_registered_pairs": 40, "n_complete_cost_pairs": all_comparison["n_complete_cost_pairs"],
                                "n_missing_cost_pairs": all_comparison["n_missing_cost_pairs"],
                                "n_issues_in_observed_pairs": estimate["n_issues"],
                                "mean_A_minus_B": estimate["estimate"], "ci95_low": estimate["ci"][0] if estimate["ci"] else None,
                                "ci95_high": estimate["ci"][1] if estimate["ci"] else None,
                                "analysis_scope": "common_dispatched_stage1" if stage == 1 else "secondary_available_pairs_stage2",
                                "all_registered_mean_difference": all_comparison["all_registered_mean_difference"],
                                "bootstrap": "issue_cluster_percentile_bootstrap", "n_resamples": 10000, "seed": metrics.DEFAULT_SEED})

runtime_summary = []
for category in sorted(runtime_counts):
    rs = [r for r in runtimes if r["category"] == category]
    runtime_summary.append({"category": category, "actual_subject_commands": len(rs),
                            "n_issues": len({r["issue_id"] for r in rs}),
                            "elapsed_seconds": sum_observed(rs, "elapsed_seconds"),
                            "missing_seconds": sum(r["elapsed_seconds"] is None for r in rs),
                            "returncode_counts": dict(Counter(str(r["returncode"]) for r in rs)),
                            "exit_status_is_scientific_verdict": False})

case_costs = []
for cid in sorted(cases):
    ps = [r for r in providers if r["case_id"] == cid]
    rs = [r for r in runtimes if r["case_id"] == cid]
    case_costs.append({**case_fields(cid), "actual_model_calls": sum(r["external_model_calls"] for r in ps),
                       "input_tokens": sum_observed(ps, "input_tokens"), "output_tokens": sum_observed(ps, "output_tokens"),
                       "total_tokens": sum_observed(ps, "total_tokens"), "provider_seconds": sum_observed(ps, "provider_seconds"),
                       "zero_call_budget_exceeded": sum(r["provider_status"] == "budget_exceeded" for r in ps),
                       "actual_subject_commands": len(rs), "subject_seconds": sum_observed(rs, "elapsed_seconds")})

review_costs = []
for path in sorted(ROOT.glob("neutral_*/reviewer_*/cost_ledger.json")):
    data = read(path)
    start = data.get("session_start") or data.get("started_at_utc")
    end = data.get("session_end") or data.get("ended_at_utc")
    seconds = (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds() if start and end else None
    recorded_seconds = data.get("elapsed_wall_seconds")
    if seconds is not None and recorded_seconds is not None:
        assert abs(seconds - recorded_seconds) < 0.000001
    if seconds is None:
        seconds = recorded_seconds
    review_costs.append({"review_group": path.parents[1].name, "reviewer": path.parent.name,
                         "reviewer_id": data.get("reviewer_id"), "session_wall_seconds": seconds,
                         "session_start": start, "session_end": end,
                         "recorded_elapsed_wall_seconds": recorded_seconds,
                         "input_tokens": data.get("input_tokens"), "output_tokens": data.get("output_tokens"),
                         "total_tokens": data.get("total_tokens", data.get("tokens")), "cost_usd": data.get("cost_usd"),
                         "tokens_missing_not_zero": True, "ledger_path": str(path),
                         "ledger_sha256": receipt(path)["sha256"], "human_labor_hours": None,
                         "included_in_10M_provider_budget": False,
                         "note": "Separate Codex agent session elapsed time, including tool use and waits; not human labor. Overlapping pair intervals are not summed as wall time."})

method_summary = []
for method in ["M1", "M2", "M3", "M4"]:
    cs = [r for r in cells if r["method"] == method]
    method_summary.append({"method": method, "registered_cells": len(cs), "n_issues": len({r["issue_id"] for r in cs}),
                           "stage1_status_counts": dict(Counter(r["stage1_status"] for r in cs)),
                           "stage2_status_counts": dict(Counter(r["stage2_status"] for r in cs)),
                           "stage1_dispatched": sum(r["stage1_calls"] for r in cs),
                           "stage2_dispatched": sum(r["stage2_calls"] for r in cs),
                           "actual_charged_tokens": sum(r["actual_charged_tokens"] for r in cs),
                           "observed_provider_seconds": sum_observed(cs, "observed_provider_seconds"),
                           "actual_subject_commands": sum(r["actual_subject_commands"] for r in cs)})

csv_write("provider_records.csv", providers)
csv_write("provider_cost_by_phase.csv", aggregate(providers, ["phase", "stage", "method"]))
csv_write("provider_cost_by_phase_method_repeat.csv", aggregate(providers, ["phase", "stage", "method", "physical_repeat", "cohort", "partition"]))
csv_write("runtime_commands.csv", runtimes)
csv_write("runtime_summary.csv", runtime_summary)
csv_write("build_commands.csv", builds)
csv_write("export_operations.csv", exports)
csv_write("historical_replay_commands.csv", replays)
csv_write("track_b_cells.csv", cells)
csv_write("track_b_method_summary.csv", method_summary)
csv_write("paired_cost_comparisons.csv", paired_flat)
csv_write("case_costs.csv", case_costs)
csv_write("review_session_costs.csv", review_costs)
dump("paired_cost_comparisons.json", paired)

audit = {
    "version": "cost-and-flow-audit.v02", "created_at": datetime.now(timezone.utc).isoformat(),
    "scope": "Pure local reads; no provider or Docker invocation; no old evidence edited.",
    "previous_version": receipt(ROOT / "cost_and_flow_audit_v01.json"),
    "change_from_previous": {
        "basis": "Re-enumerated canonical runtime/export/provider files; differences joined by artifact path, not by adding expected constants.",
        "new_subject_commands": len(new_runtime_rows),
        "new_subject_seconds": sum_observed(new_runtime_rows, "elapsed_seconds"),
        "new_runtime_receipts": [receipt(r["result_path"]) for r in new_runtime_rows],
        "new_file_export_operations": len(new_export_rows),
        "new_exported_file_entries": sum(r["file_entries"] for r in new_export_rows),
        "new_export_receipts": [receipt(r["manifest_path"]) for r in new_export_rows],
        "provider_calls_delta": len(actual) - previous_audit["provider_reconciliation"]["actual_provider_calls"],
        "provider_tokens_delta": charged - previous_audit["provider_reconciliation"]["actual_charged_tokens"],
        "HF001_evaluation_supplement": receipt(hf001_supplement_path),
        "P1_fixed_pairs_changed": False},
    "source_cases": receipt(ROOT / "cases.json"),
    "denominators": {"cases": 60, "distinct_issues": len({r["task"] for r in cases.values()}),
                     "partition_counts": dict(Counter(r["partition"] for r in cases.values())),
                     "cohort_counts": dict(Counter(r["cohort"] for r in cases.values())),
                     "track_b_cells": 160, "cells_per_method": 40, "issues_per_method": 20,
                     "physical_repeats_per_issue_method": 2,
                     "physical_repeats_are_independent_issues": False},
    "provider_reconciliation": {
        "ledger": receipt(ROOT / "provider_budget.json"), "limit_tokens": ledger["limit_tokens"],
        "ledger_entries": len(ledger_keys), "ledger_status_counts": dict(Counter(r["status"] for r in ledger["calls"].values())),
        "actual_charged_tokens": charged, "remaining_tokens": ledger["limit_tokens"] - charged,
        "utilization_fraction": charged / ledger["limit_tokens"],
        "canonical_provider_manifests": len(providers), "actual_provider_calls": len(actual),
        "zero_call_budget_exceeded_manifests": len(providers) - len(actual),
        "unique_budget_keys": len(keys), "duplicate_actual_budget_keys": [k for k, n in key_counts.items() if n > 1],
        "ledger_keys_without_manifest": sorted(ledger_keys - keys), "actual_manifest_keys_without_ledger": sorted(keys - ledger_keys),
        "usage_or_request_sha_mismatches": mismatches, "all_280_have_usage_and_seconds": all(r["total_tokens"] is not None and r["provider_seconds"] is not None for r in actual),
        "actual_input_tokens": sum(r["input_tokens"] for r in actual), "actual_output_tokens": sum(r["output_tokens"] for r in actual),
        "sum_provider_seconds": sum(r["provider_seconds"] for r in actual),
        "requested_model_counts": dict(Counter(r["requested_model"] for r in actual)),
        "response_model_counts": dict(Counter(r["response_model"] for r in actual)),
        "dedup_policy": "Only canonical runs/**/provider/manifest.json. Join each actual call by unique budget_key and verify request SHA and provider usage against ledger. Neutral packet copies, wrapper receipts, and generation-boundary ledger snapshots excluded.",
        "timing_scope": "Sum of measured request durations, not whole-study elapsed wall clock or monetary cost."},
    "provider_cost_by_phase": aggregate(providers, ["phase", "stage", "method"]),
    "runtime_audit": {
        "actual_subject_commands": len(runtimes), "categories": runtime_summary,
        "phase_counts": dict(Counter(r["phase"] for r in runtimes)),
        "dedup_policy": "Only canonical runs/**/result.json with its own execution.command; one row per runtime leaf. Count physical repetitions even when command SHA matches. Exclude control subrecord copies, summaries, neutral packets, and historical replay.",
        "unique_raw_stdout_paths": len({r["raw_stdout"] for r in runtimes}),
        "separate_build_commands": len(builds), "build_seconds": sum_observed(builds, "elapsed_seconds"),
        "separate_file_export_operations": len(exports), "export_kind_counts": dict(Counter(r["kind"] for r in exports)),
        "export_seconds": None, "export_seconds_reason": "No elapsed-time measurement in these export manifests; never imputed as zero.",
        "separate_historical_replay_commands": len(replays), "historical_replay_issues": len({r["issue_id"] for r in replays}),
        "historical_replay_seconds": sum_observed(replays, "elapsed_seconds"),
        "historical_replay_version_counts": dict(Counter(r["phase"] for r in replays)),
        "historical_replay_scope": "2997 new-run replay receipts for the 20 reserved trajectories; earlier-run checkpoint construction is outside NEW and excluded.",
        "exit_status_policy": "Exit code, timeout, and command execution counts are technical evidence, not test truth or oracle/masking labels."},
    "track_b_flow": {
        "stage1_counts": dict(Counter(r["stage1_status"] for r in cells)),
        "stage1_calls": sum(r["stage1_calls"] for r in cells),
        "stage2_counts": dict(Counter(r["stage2_status"] for r in cells)),
        "stage2_calls": sum(r["stage2_calls"] for r in cells),
        "stage2_zero_call_budget_missing": 36,
        "wrapper_misclassification": "36 stage2 result.json wrappers say invalid_response after absent completion.txt; authoritative provider.status=budget_exceeded and external_model_calls=0. These are budget-missing, never observed method-response failures.",
        "target_plans": 8, "target_subject_commands": 96, "target_qualified_for_stage2": 0,
        "target_audit": receipt(ROOT / "track_b_target_execution_audit_v01.json"),
        "candidate_execution_cells": len(candidate_mapping),
        "direct_candidate_P_commands": runtime_counts["track_b_direct_candidate_P"],
        "postfreeze_evaluator_Q_commands": runtime_counts["track_b_postfreeze_evaluator_Q"],
        "candidate_semantics": receipt(ROOT / "evidence_aggregation_v01/semantic_reviews.json"),
        "HF001_candidate_semantic_supplement": receipt(hf001_supplement_path),
        "semantic_policy": "Existing A/B/C judgments retained; HF001 cells additionally use new independent A/B evaluator supplement. Original and augmented Q both fail the same original assertion, so paired executability is established without added discrimination. No inference from shell return codes; P1 fixed pairs unchanged.",
        "methods": method_summary},
    "missing_cost_policy": "CSV empty and JSON null mean unavailable measurement, not zero. Zero actual_charged_tokens is used only when external_model_calls=0 establishes no provider expenditure. Stage costs of uncalled/missing generation remain null; no hypothetical complete-method cost is imputed.",
    "paired_cost_analysis": {
        "implementation": receipt(metric_path), "n_resamples": 10000, "seed": metrics.DEFAULT_SEED,
        "stage1": "Every pairwise method comparison uses same-issue same-repeat pairs: 36 common-dispatched pairs / 18 issues. The 40-registered-pair audit retains four input-unavailable pairs per comparison with null cost. No filtering on success.",
        "stage2": "Only M1/M2 have reached stage2; compare measured overlapping completions as secondary available-pairs analysis. All 40 registrations retained, and all-pairs cost estimate and CI are null.",
        "uncertainty": "Bootstrap resamples whole issue clusters with all physical repeats; repeats do not increase independent issue sample size.",
        "full_results": receipt(OUT / "paired_cost_comparisons.json")},
    "review_costs": {"sessions": review_costs, "tokens": None, "cost_usd": None,
                     "note": "Independent Codex semantic reviews have agent wall-time ledgers including tool use/waits, not human labor. Token/money usage is unavailable. They are separate from the external provider ledger; unknown overhead prevents claiming a complete all-in study token cost."},
    "sources": [receipt(ROOT / "budget_authorization.json"), receipt(ROOT / "protocol.json"),
                receipt(ROOT / "amendments/007_track_b_execution_contract.json"),
                receipt(ROOT / "amendments/018_hf001_postfreeze_evaluator.json"),
                receipt(hf001_supplement_path)],
    "outputs": [receipt(p) for p in sorted(OUT.iterdir()) if p.is_file()],
    "validation": {"ledger_reconciled": True, "runtime_835_verified": True, "exports_225_verified": True,
                   "160_cells_retained": True, "12_added_runtime_paths_verified": True,
                   "HF001_supplement_used_for_two_cells": sum(r.get("semantic_source") == str(hf001_supplement_path) for r in cells) == 2,
                   "stage1_status_counts_verified": True, "stage2_budget_missing_corrected_only_in_audit": True,
                   "new_provider_calls": 0, "new_docker_commands": 0},
}
(ROOT / "cost_and_flow_audit_v02.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"output": str(ROOT / "cost_and_flow_audit_v02.json"), "provider_calls": len(actual),
                  "tokens": charged, "subject_commands": len(runtimes), "builds": len(builds),
                  "exports": len(exports), "historical_replays": len(replays), "cells": len(cells),
                  "paired_rows": len(paired), "stage2_complete_pairs": next(p["all_40_registered_pairs"]["n_complete_cost_pairs"] for p in paired if p["stage"] == 2)}))
