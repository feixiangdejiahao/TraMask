"""Read-only inventory chronology audit of the 280 already bound physical calls.

Creates new addendum files. Does not change the original immutable audit summary.
"""
import collections
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
RUN = OUT.parent
ROOT = RUN.parents[2]
sys.path.insert(0, str(ROOT / "src"))
from tramask_pilot.corpus import calls as raw_calls


def read(path):
    return json.loads(Path(path).read_text())


def receipt(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def walk(value, pointer=""):
    if isinstance(value, dict):
        for key, item in value.items():
            yield pointer + "/" + key, key, item
            yield from walk(item, pointer + "/" + key)
    elif isinstance(value, list):
        for i, item in enumerate(value):
            yield from walk(item, pointer + "/" + str(i))


def main():
    destination = OUT / "chronology_visibility_addendum.json"
    report_path = OUT / "chronology_visibility_addendum.txt"
    if destination.exists() or report_path.exists():
        raise FileExistsError("Refusing to overwrite existing addendum")
    codec_path = RUN / "code_versions/track_b_dispatch_v04/src/tramask_rerun/prompt_codec.py"
    spec = importlib.util.spec_from_file_location("_chronology_audit_codec", codec_path)
    codec = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(codec)
    bound_calls = read(OUT / "calls.json")
    field_counts, metadata_hits, literal_action_id_hits = collections.Counter(), [], []
    stage1 = collections.defaultdict(list)
    methods = collections.Counter()
    temporal_keys = {"step", "step_id", "action_id", "action_ids", "execution_call_id", "call_id", "timestamp", "created_at", "ordinal", "source_index", "version_action_id", "version_action_ids", "submission_event_index", "invocation_provenance", "file_receipts", "version"}
    for row in bound_calls:
        request_path = Path(row["request_file"]["path"])
        assert receipt(request_path) == row["request_file"]
        request = read(request_path)
        material = codec.decode_payload(json.loads(request["messages"][1]["content"]))["material"]
        tests = material.get("validation_tests", []) + ([material["selected_test"]] if "selected_test" in material else [])
        for test in tests:
            field_counts.update(list(test))
            for pointer, key, value in walk(test):
                # File path keys and original string contents are not injected metadata.
                if key in temporal_keys and not pointer.startswith(("/files/", "/file_excerpts/")):
                    metadata_hits.append({"call": row["call"], "test_id": test["id"], "pointer": pointer, "value": value})
            for pointer, key, value in walk(test):
                if isinstance(value, str):
                    matches = sorted(set(re.findall(r"\bs\d+_c\d+\b", value)))
                    if matches:
                        literal_action_id_hits.append({"call": row["call"], "test_id": test["id"], "pointer": pointer, "tokens": matches, "interpretation": "raw string content; review separately from metadata"})
        if "/track_b/" in row["call"]:
            parts = Path(row["call"]).parts
            methods[parts[3] + "/" + parts[5]] += 1
            if parts[5] == "stage_01":
                packet = read(row["public_input"]["path"])
                actual = [(t["id"], t["command"]) for t in material["validation_tests"]]
                stored = [(t["id"], t["command"]) for t in packet["validation_tests"]]
                assert actual == stored
                stage1[row["case_id"]].append({"call": row["call"], "test_sequence": actual,
                    "actual_serialized_array_preserves_public_packet_order": True,
                    "test_ids_are_opaque_hashes": all(re.fullmatch(r"validation_[0-9a-f]{24}", t["id"]) for t in material["validation_tests"])})
    cases = []
    for case_id, records in sorted(stage1.items()):
        sequence = records[0]["test_sequence"]
        assert all(row["test_sequence"] == sequence for row in records)
        trajectory = RUN / "inputs" / case_id / "trajectory.json"
        action_order = {row["id"]: i for i, row in enumerate(raw_calls(read(trajectory)))}
        authorities = []
        for qpath in sorted((RUN / "runs" / case_id).glob("qualified_validation_inventory*.json")):
            document = read(qpath)
            if [(t["id"], t["command"]) for t in document["validation_tests"]] == sequence:
                authorities.append((qpath, document))
        assert authorities
        candidates = []
        for qpath, qualification in authorities:
            ordering = []
            for position, test in enumerate(qualification["validation_tests"]):
                ids = [row.get("execution_call_id") or row.get("call_id") for row in test.get("invocation_provenance", [])]
                ids.append(test.get("representative_execution_call_id"))
                observed = sorted({(action_order[identity], identity) for identity in ids if identity in action_order})
                ordering.append({"array_position_zero_based": position, "test_id": test["id"],
                    "earliest_bound_invocation_action_index": observed[0][0] if observed else None,
                    "earliest_bound_invocation_action_id": observed[0][1] if observed else None,
                    "bound_invocation_action_ids": [identity for _, identity in observed]})
            candidates.append((qpath, ordering))
        ordering = candidates[0][1]
        assert all([r["earliest_bound_invocation_action_index"] for r in rows] == [r["earliest_bound_invocation_action_index"] for r in ordering] for _, rows in candidates)
        indices = [r["earliest_bound_invocation_action_index"] for r in ordering]
        known = all(index is not None for index in indices)
        inversions = sum(a > b for a, b in zip(indices, indices[1:]) if a is not None and b is not None)
        cases.append({"case_id": case_id, "physical_stage1_calls": len(records), "unique_test_entries": len(sequence),
            "all_arms_and_repeats_have_identical_array_order": True,
            "all_invocation_positions_bound": known, "adjacent_order_inversions": inversions,
            "array_is_nondecreasing_original_invocation_order": known and inversions == 0,
            "test_ids_are_opaque_hashes": all(r["test_ids_are_opaque_hashes"] for r in records),
            "trajectory": receipt(trajectory), "matching_inventory_authorities": [receipt(p) for p, _ in candidates],
            "test_order_with_unexposed_audit_only_action_bindings": ordering,
            "physical_calls": [r["call"] for r in records]})
    result = {"version": "serialized-input-chronology-visibility-addendum.v1", "created_at": datetime.now(timezone.utc).isoformat(),
        "script": receipt(__file__), "parent_summary": receipt(RUN / "serialized_input_provenance_audit_v01.json"),
        "actual_calls_authority": receipt(OUT / "calls.json"), "codec": receipt(codec_path),
        "actual_calls_screened": len(bound_calls), "actual_test_object_occurrences": sum(field_counts[k] for k in ["id"]),
        "actual_test_object_top_level_field_occurrences": dict(field_counts),
        "explicit_temporal_metadata_hits": metadata_hits, "literal_raw_action_id_string_hits": literal_action_id_hits,
        "actual_track_b_call_counts": dict(methods), "physical_stage1_calls": sum(len(v) for v in stage1.values()),
        "stage1_cases": len(cases), "unique_stage1_test_entries": sum(row["unique_test_entries"] for row in cases),
        "stage1_cases_retaining_invocation_chronology_in_array_order": sum(row["array_is_nondecreasing_original_invocation_order"] for row in cases),
        "cases": cases, "actual_C4_calls": 0,
        "findings": [
            "No explicit step/action ID/timestamp/version-action metadata fields are present in the actual test objects. Test IDs are opaque content identities, not chronological ordinals.",
            "All 18 physical Track B cases preserve nondecreasing original-invocation order in the shared validation_tests array; this is visible in all 144 stage1 payloads, including M1/M3. Array order is an implicit chronology signal.",
            "Original commands, paths, inline bodies and file text are preserved. Their ordinary filenames, comments or content evolution may also reveal historical relations; deleting explicit metadata is not full chronology removal.",
            "M2/M4 add selected raw command/output events to the shared historical-test inventory; M1/M3 cannot be described as receiving no historical or chronological information.",
            "C4 has no actual provider call in these 280 physical requests. Any prepared-only C3/C4 event-multiset checks are a separate preflight result, not an executed chronology ablation."
        ], "limitations": ["Inventory order is tied to the earliest archived invocation per test identity; repeat invocations may span later history.",
            "The audit does not estimate how much the model used this ordering or the causal effect of retained test chronology.",
            "The original immutable audit summary and its script were not changed. This is an additive interpretation finding, not an amendment to model inputs."]}
    with destination.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    with report_path.open("x") as stream:
        stream.write("Chronology visibility addendum\n\n" + "\n\n".join(result["findings"]) + "\n")
    print(json.dumps({key: result[key] for key in ("actual_calls_screened", "physical_stage1_calls", "stage1_cases", "unique_stage1_test_entries", "stage1_cases_retaining_invocation_chronology_in_array_order", "actual_C4_calls")}, indent=2))


if __name__ == "__main__":
    main()
