"""F004 chronological replay with a single recorded CPU-visibility adaptation."""
from pathlib import Path
import ast
import hashlib
import json
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'src'))
from tramask_pilot.corpus import RUN, read, write, receipt
from tramask_pilot.runtime import Container
from tramask_pilot import submission_replay as replay
from tramask_pilot.submission_state import validate_submission_state

OUT = Path(__file__).parent / 'F004'
SOURCE = RUN / 'inputs/F004'
SHIM = """'use strict';
const os = require('node:os');
const original = os.cpus;
os.cpus = function() { return original.call(os).slice(0, 2); };
"""


def independent_prebuild_sources(actions):
    byid = {a['id']: a for a in actions}
    expected = {}
    for action_id, path in [('s15_c0', 'src/types/MatchEach.ts'),
                            ('s16_c0', 'src/match-each.ts'),
                            ('s17_c0', 'src/index.ts')]:
        text = byid[action_id]['command']
        expected[path] = text.split("<<'EOF'\n", 1)[1].split('\nEOF', 1)[0] + '\n'
    for action_id, path in [('s19_c0', 'src/match-each.ts'),
                            ('s24_c0', 'src/types/MatchEach.ts')]:
        program = byid[action_id]['command'].split("<<'PY'\n", 1)[1].split('\nPY', 1)[0]
        values = {'s': expected[path]}
        def value(node):
            return values[node.id] if isinstance(node, ast.Name) else ast.literal_eval(node)
        for node in ast.parse(program).body:
            if not isinstance(node, ast.Assign):
                continue
            name = node.targets[0].id
            expr = node.value
            if isinstance(expr, ast.Call):
                if isinstance(expr.func, ast.Attribute) and expr.func.attr == 'replace':
                    assert isinstance(expr.func.value, ast.Name) and expr.func.value.id == 's'
                    old, new = [value(arg) for arg in expr.args]
                    assert old in values['s']
                    values[name] = values['s'].replace(old, new)
                else:
                    assert name == 's'  # original open(p).read(); input is already frozen above
            else:
                values[name] = value(expr)
        expected[path] = values['s']
    return expected


def main():
    case = next(c for c in read(RUN / 'selection_order.json')['failed_order'] if c['id'] == 'F004')
    actions, marker = replay.submission_actions(read(SOURCE / 'trajectory.json'))
    expected_sources = independent_prebuild_sources(actions)
    OUT.mkdir(parents=True, exist_ok=False)
    shim_local = OUT / 'cpu_visibility_2.cjs'
    shim_local.write_text(SHIM)
    write(OUT / 'plan.json', {
        'created_at': datetime.now(timezone.utc).isoformat(), 'case': case,
        'trajectory': receipt(SOURCE / 'trajectory.json'), 'model_patch': receipt(SOURCE / 'model.patch'),
        'action_count': len(actions), 'terminal_marker': marker['id'],
        'strategy': 'full chronological replay from original image; no patch transplant',
        'amendment': {'action': 's37_c0', 'reason': 'os.cpus exposes 384 host CPUs despite the original task CPU allocation of 2; terser defaults to 383 worker processes and fails EPIPE',
            'method': 'Only s37 NODE_OPTIONS requires temporary shim making os.cpus return first 2 CPUs',
            'shim': receipt(shim_local), 'cpu_limit': 2, 'memory': '8g', 'timeout_seconds': 30,
            'exact_recorded_command_preserved': True, 'tracked_or_dependency_source_modified': False,
            'shim_removed_after_action': True, 'subsequent_environment_restored': True},
        'code': [receipt(Path(__file__)), receipt(Path(replay.__file__)),
                 receipt(ROOT / 'src/tramask_pilot/submission_state.py')],
        'previous_attempt': receipt(RUN / 'submission_state_audit/full_replay_v01/F004/summary.json'),
    })
    records = []
    prebuild = None
    with Container(case['image'], OUT / 'runtime', case['base_commit']) as runtime:
        for i, action in enumerate(actions):
            write(OUT / 'progress.json', {'completed': i, 'total': len(actions), 'executing': action['id']})
            if action['id'] == 's37_c0':
                snapshot = runtime.snapshot('before_build_s37')
                prebuild = runtime.checkpoint('before_build_s37')
                evidence = []
                for path, expected in expected_sources.items():
                    actual = runtime._control(['cat', '/app/' + path]).stdout
                    item = {'path': path, 'expected_sha256': hashlib.sha256(expected.encode()).hexdigest(),
                            'actual_sha256': hashlib.sha256(actual).hexdigest(), 'matches': actual == expected.encode()}
                    evidence.append(item)
                    assert item['matches'], path
                changed = runtime._control(['git', 'diff', '--name-only', case['base_commit'], '--']).stdout.decode().splitlines()
                assert set(changed) <= {'src/index.ts', 'src/match-each.ts', 'src/types/MatchEach.ts', 'tests/match-each.test.ts'}
                write(OUT / 'prebuild_source_authority.json', {
                    'method': 'Independent literal extraction of original s15/s16/s17 heredocs plus AST-literal replacements from s19/s24; no trajectory shell code executed on host.',
                    'expected_production_paths': evidence, 'tracked_changed_paths': changed,
                    'snapshot': snapshot, 'checkpoint': prebuild,
                    'limit': 'Production source compared independently; tests preserved in full source snapshot and chronological commands.'})
                remote_shim = runtime.scratch + '/cpu_visibility_2.cjs'
                runtime.copy_to(shim_local, remote_shim)
                original_env = replay.ENV
                replay.ENV = dict(original_env, NODE_OPTIONS='--require=' + remote_shim)
                try:
                    result = replay.execute_action(runtime, action)
                finally:
                    replay.ENV = original_env
                    runtime._control(['rm', '-f', '--', remote_shim])
                result['resource_adaptation'] = {'NODE_OPTIONS': '--require=' + remote_shim,
                    'os_cpus_visible_count': 2, 'shim_sha256': receipt(shim_local)['sha256'],
                    'scoped_to_single_call': True, 'shim_removed': True}
                write(runtime.output / 'calls' / action['id'] / 'result.json', result)
                runtime._persist()
            else:
                result = replay.execute_action(runtime, action)
            records.append(result)
        (OUT / 'processes.txt').write_bytes(runtime._control(['ps', '-eo', 'pid,ppid,pgid,args'], check=False).stdout)
        checkpoint = runtime.checkpoint('before_submission')
        (OUT / 'docker_diff.txt').write_bytes(runtime._docker(['diff', runtime.name]).stdout)
        original_scratch, image_id = runtime.scratch, runtime.image_id
    with Container(checkpoint['image_id'], OUT / 'frozen_state', checkpoint['head']) as frozen:
        remote_inventory = original_scratch + '/submission_inventory.json'
        frozen._control(['python3', '-c', replay.INVENTORY], timeout=600,
            input_bytes=json.dumps({'scratch': original_scratch, 'destination': remote_inventory}).encode())
        frozen.copy_from(remote_inventory, OUT / 'filesystem_inventory.json')
        validation = validate_submission_state(frozen, SOURCE / 'model.patch', OUT / 'validation_v03', base_commit=case['base_commit'])
        expected_declaration = next(a for a in actions if a['id'] == 's54_c0')['expected']['output'].encode()
        actual_declaration = frozen._control(['cat', '/app/dist/match-each.d.ts']).stdout
        final_dist = [row for row in read(OUT / 'filesystem_inventory.json')['files'] if row['path'].startswith('/app/dist/')]
        checks = []
        for label in ['s38_c0', 's41_c0', 's46_c0', 's54_c0']:
            action = next(a for a in actions if a['id'] == label)
            current = (OUT / 'runtime/calls' / label / 'output.bin').read_bytes()
            historical = action['expected']['output'].encode()
            checks.append({'id': label, 'matches_original_file_read_or_runtime_witness': current == historical,
                           'original_sha256': hashlib.sha256(historical).hexdigest(),
                           'replay_sha256': hashlib.sha256(current).hexdigest()})
        generated = {'dist_file_count': len(final_dist), 'dist_inventory': final_dist,
            'declaration_byte_equality_with_original_s54': actual_declaration == expected_declaration,
            'original_file_read_and_runtime_witnesses': checks,
            'limit': 'Exact original full dist manifest unavailable; archived directory/declaration reads and s41 runtime witness provide independent checks.'}
        write(OUT / 'generated_state_validation.json', generated)
        assert validation['submission_state_status'] == 'matched'
        assert final_dist and actual_declaration == expected_declaration
        assert all(c['matches_original_file_read_or_runtime_witness'] for c in checks)
        write(OUT / 'validation_v03/provenance.json', {'source_checkpoint': checkpoint,
            'code': receipt(ROOT / 'src/tramask_pilot/submission_state.py'),
            'replay_plan': receipt(OUT / 'plan.json'), 'scope': 'Read-only validation of frozen filesystem after complete chronological replay with recorded one-call CPU-visibility adaptation.'})
        summary = {'id': 'F004', 'actions_executed': len(records), 'terminal_marker': marker['id'],
            'image_id': image_id, 'checkpoint': checkpoint, 'validation': validation,
            'output_equality_used': False, 'generic_output_equality_used': False,
            'artifact_specific_reads_and_runtime_witnesses_compared': True,
            'timeouts': [r['id'] for r in records if r['timed_out']],
            'returncode_differences': [r['id'] for r in records if r['original_returncode'] is not None and r['returncode'] != r['original_returncode']],
            'inventory': receipt(OUT / 'filesystem_inventory.json'),
            'prebuild_source_authority': receipt(OUT / 'prebuild_source_authority.json'),
            'generated_state_validation': receipt(OUT / 'generated_state_validation.json'),
            'resource_adaptation': receipt(OUT / 'plan.json'),
            'scope': 'Full chronological replay; committed and working tracked trees verified; missing dist restored at its original historical build point and verified by archived reads/runtime witness. Full original disk manifest unavailable.'}
        write(OUT / 'summary.json', summary)
        write(OUT / 'progress.json', {'completed': len(actions), 'total': len(actions), 'executing': 'complete'})
        print(json.dumps({'case_id': 'F004', 'status': validation['submission_state_status'], 'dist_files': len(final_dist), 'summary': str(OUT / 'summary.json')}), flush=True)


if __name__ == '__main__':
    main()
