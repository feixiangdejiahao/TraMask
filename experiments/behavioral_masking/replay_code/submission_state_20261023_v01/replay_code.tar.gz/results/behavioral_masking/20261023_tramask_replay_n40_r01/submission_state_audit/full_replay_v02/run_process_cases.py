"""Chronological F027/S026 replay with explicit original process-lifecycle bindings."""
from pathlib import Path
from datetime import datetime, timezone
import json
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'src'))
from tramask_pilot.corpus import RUN, read, write, receipt
from tramask_pilot.runtime import Container
from tramask_pilot import submission_replay as replay
from tramask_pilot.submission_state import validate_submission_state

PROCESSES = r'''
import json,os
rows=[]
for name in os.listdir('/proc'):
    if not name.isdigit():continue
    try:
        stat=open('/proc/'+name+'/stat').read().rsplit(')',1)[1].split()
        argv=[x.decode(errors='replace') for x in open('/proc/'+name+'/cmdline','rb').read().split(b'\0') if x]
        rows.append({'pid':int(name),'ppid':int(stat[1]),'pgid':int(stat[2]),'state':stat[0],
                     'start_ticks':int(stat[19]),'argv':argv})
    except (OSError,ValueError):pass
print(json.dumps(sorted(rows,key=lambda r:r['pid'])))
'''


def processes(runtime):
    return json.loads(runtime._control(['python3', '-c', PROCESSES]).stdout)


def same_process(row, binding):
    return row['pid'] == binding['pid'] and row['start_ticks'] == binding['start_ticks']


def active(rows):
    return [row for row in rows if row['state'] not in ('Z', 'X')]


def execute_mapped(runtime, action, effective, mapping):
    directory = runtime.output / 'calls' / action['id']
    directory.mkdir(parents=True, exist_ok=False)
    (directory / 'command.sh').write_text(action['command'])
    (directory / 'execution_command.sh').write_text(effective)
    write(directory / 'archived_expected.json', action['expected'])
    write(directory / 'execution_mapping.json', mapping)
    remote = runtime.scratch + '/' + action['id'] + '.output'
    raw = runtime._control(['python3', '-c', replay.EXECUTE], timeout=60,
        input_bytes=json.dumps({'command': effective, 'env': replay.ENV, 'output': remote}).encode())
    result = json.loads(raw.stdout)
    runtime.copy_from(remote, directory / 'output.bin')
    result.update(id=action['id'], command_sha256=receipt(directory / 'command.sh')['sha256'],
        execution_command_sha256=receipt(directory / 'execution_command.sh')['sha256'],
        execution_mapping=receipt(directory / 'execution_mapping.json'),
        shell='/bin/sh', timeout_seconds=30, working_directory='/app',
        original_returncode=(action['expected'] or {}).get('returncode'), output_compared=False)
    write(directory / 'result.json', result)
    runtime.records.append(result)
    runtime._persist()
    return result


def main(case_id):
    assert case_id in ('F027', 'S026')
    selection = read(RUN / 'selection_order.json')
    case = next(c for c in selection['failed_order'] + selection['successful_order'] if c['id'] == case_id)
    out = Path(__file__).parent / case_id
    source = RUN / 'inputs' / case_id
    document = read(source / 'trajectory.json')
    actions, marker = replay.submission_actions(document)
    out.mkdir(parents=True, exist_ok=False)
    write(out / 'plan.json', {
        'created_at': datetime.now(timezone.utc).isoformat(), 'case': case,
        'trajectory': receipt(source / 'trajectory.json'), 'model_patch': receipt(source / 'model.patch'),
        'action_count': len(actions), 'terminal_marker': marker['id'],
        'strategy': 'all recorded commands in original order from original image; no patch transplant',
        'adaptation': ('At s101 bind original PID 6506 to the unique webhook process observed after original s48 launch; retain original command and save effective command separately.' if case_id == 'F027' else
            'After original s80 log-completion read, wait for the same background go test process launched at s39 to terminate; preserve all original commands and record barrier separately.'),
        'resources': {'cpus': 2, 'memory': '8g', 'timeout_seconds': 30},
        'source_or_dependency_edits_by_adapter': False, 'provider_calls': 0,
        'original_step_timestamps': {str(s['step_id']): s.get('timestamp') for s in document['steps']
            if s['step_id'] in ([48, 100, 101, 102] if case_id == 'F027' else [39, 40, 41, 80, 81, 89])},
        'code': [receipt(Path(__file__)), receipt(Path(replay.__file__)), receipt(ROOT / 'src/tramask_pilot/submission_state.py')],
        'previous_attempt': receipt(RUN / 'submission_state_audit/full_replay_v01' / case_id / 'summary.json'),
    })
    records = []
    binding = None
    barrier = None
    with Container(case['image'], out / 'runtime', case['base_commit'], cpus=2, memory='8g') as runtime:
        for i, action in enumerate(actions):
            write(out / 'progress.json', {'completed': i, 'total': len(actions), 'executing': action['id']})
            if case_id == 'F027' and action['id'] == 's101_c0':
                before = processes(runtime)
                candidates = [p for p in active(before) if same_process(p, binding)]
                assert len(candidates) == 1 and candidates[0]['argv'] == binding['argv'], candidates
                assert action['command'].startswith('kill 6506 2>/dev/null;')
                effective = action['command'].replace('kill 6506 ', 'kill ' + str(binding['pid']) + ' ', 1)
                mapping = {'original_pid': 6506, 'replay_process': binding, 'before_action_process': candidates[0],
                    'original_launch_action': 's48_c0', 'original_process_observation_action': 's100_c0',
                    'reason': 'PID is a dynamic handle for the same explicitly launched webhook server',
                    'changed_only_original_kill_pid': True, 'all_other_command_bytes_preserved': True}
                result = execute_mapped(runtime, action, effective, mapping)
            else:
                result = replay.execute_action(runtime, action)
            records.append(result)
            if case_id == 'F027' and action['id'] == 's48_c0':
                candidates = [p for p in active(processes(runtime)) if p['argv'] == ['python3', '/tmp/webhook_server.py']]
                assert len(candidates) == 1, candidates
                binding = candidates[0]
                write(out / 'process_binding.json', {'after_action': action['id'], 'binding': binding,
                    'selection': 'unique exact argv python3 /tmp/webhook_server.py after the recorded launch',
                    'original_pid': 6506, 'original_pid_evidence_action': 's100_c0'})
            if case_id == 'S026' and action['id'] == 's39_c0':
                observed = (out / 'runtime/calls/s39_c0/output.bin').read_text()
                pid = int(re.search(r'test pid (\d+)', observed).group(1))
                candidates = [p for p in active(processes(runtime)) if p['pid'] == pid]
                assert len(candidates) == 1 and candidates[0]['argv'] == ['go', 'test', './...'], candidates
                binding = candidates[0]
                write(out / 'process_binding.json', {'after_action': action['id'], 'binding': binding,
                    'selection': 'PID returned by original background test launch, verified against exact argv and process start time'})
            if case_id == 'S026' and action['id'] == 's80_c0':
                started = time.monotonic()
                observations = []
                while True:
                    rows = processes(runtime)
                    alive = [p for p in active(rows) if same_process(p, binding)]
                    observations.append({'elapsed_seconds': time.monotonic() - started, 'target': alive,
                        'active_same_group': [p for p in active(rows) if p['pgid'] == binding['pgid']]})
                    barrier = {'after_action': 's80_c0', 'before_action': 's81_c0', 'binding': binding,
                        'reason': 'Original s80 reads the completed full test log; missing model thinking delays left that same test active in v01.',
                        'criterion': 'bound go test process terminated; exit success not required; no log equality used',
                        'elapsed_seconds': time.monotonic() - started, 'completed': not alive,
                        'no_process_signals_sent': True, 'observations': observations}
                    write(out / 'completion_barrier.json', barrier)
                    write(out / 'progress.json', {'completed': i + 1, 'total': len(actions),
                        'executing': 'completion_barrier_after_s80_c0', 'elapsed_seconds': barrier['elapsed_seconds']})
                    if not alive:
                        break
                    if time.monotonic() - started > 900:
                        raise TimeoutError('Bound go test still running after 900-second observation barrier; no kill performed')
                    time.sleep(2)
        final_processes = processes(runtime)
        (out / 'processes.txt').write_bytes(runtime._control(['ps', '-eo', 'pid,ppid,pgid,args'], check=False).stdout)
        write(out / 'terminal_processes.json', final_processes)
        if case_id == 'F027':
            survivors = [p for p in active(final_processes) if p['argv'] in
                (['python3', '/tmp/webhook_server.py'], ['python3', '/tmp/alert_test.py'])]
        else:
            survivors = [p for p in active(final_processes) if p['pgid'] == binding['pgid']]
        quiescence = {'case_id': case_id, 'binding': binding, 'known_processes_quiescent': not survivors,
            'survivors': survivors, 'terminal_processes': receipt(out / 'terminal_processes.json'),
            'original_evidence': (['s93_c0', 's100_c0', 's101_c0'] if case_id == 'F027' else ['s39_c0', 's41_c0', 's80_c0']),
            'scope': 'Only the explicitly bound original background process lifecycle; not full machine memory equivalence.'}
        write(out / 'process_state_validation.json', quiescence)
        checkpoint = runtime.checkpoint('before_submission')
        (out / 'docker_diff.txt').write_bytes(runtime._docker(['diff', runtime.name]).stdout)
        original_scratch, image_id = runtime.scratch, runtime.image_id
    with Container(checkpoint['image_id'], out / 'frozen_state', checkpoint['head'], cpus=2, memory='8g') as frozen:
        remote = original_scratch + '/submission_inventory.json'
        frozen._control(['python3', '-c', replay.INVENTORY], timeout=600,
            input_bytes=json.dumps({'scratch': original_scratch, 'destination': remote}).encode())
        frozen.copy_from(remote, out / 'filesystem_inventory.json')
        validation = validate_submission_state(frozen, source / 'model.patch', out / 'validation_v03', base_commit=case['base_commit'])
        write(out / 'validation_v03/provenance.json', {'source_checkpoint': checkpoint,
            'code': receipt(ROOT / 'src/tramask_pilot/submission_state.py'), 'replay_plan': receipt(out / 'plan.json'),
            'scope': 'Independent read-only validation of frozen filesystem after complete chronological replay with explicit process-lifecycle adaptation.'})
        summary = {'id': case_id, 'actions_executed': len(records), 'terminal_marker': marker['id'],
            'image_id': image_id, 'checkpoint': checkpoint, 'validation': validation,
            'output_equality_used': False, 'timeouts': [r['id'] for r in records if r['timed_out']],
            'returncode_differences': [r['id'] for r in records if r['original_returncode'] is not None and r['returncode'] != r['original_returncode']],
            'inventory': receipt(out / 'filesystem_inventory.json'),
            'process_state_validation': receipt(out / 'process_state_validation.json'),
            'process_adaptation': receipt(out / 'plan.json'), 'known_processes_quiescent': not survivors,
            'scope': 'Full chronological replay; submitted tracked trees independently verified; known background process lifecycle checked. No original full filesystem or process memory manifest exists.'}
        write(out / 'summary.json', summary)
        write(out / 'progress.json', {'completed': len(actions), 'total': len(actions), 'executing': 'complete'})
        print(json.dumps({'case_id': case_id, 'tracked_status': validation['submission_state_status'],
            'known_processes_quiescent': not survivors, 'barrier_seconds': barrier['elapsed_seconds'] if barrier else None,
            'summary': str(out / 'summary.json')}), flush=True)
        assert validation['submission_state_status'] == 'matched'
        assert not survivors, survivors


if __name__ == '__main__':
    main(sys.argv[1])
